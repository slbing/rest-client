﻿WisdomTool REST Client是由个人所开发的一款自动化测试RESTful API的工具。

它可以自动化测试RESTful API并生成精美的测试报告，同时基于测试过的历史数据，可以自动生成RESTful API文档。

源码的作者靠写代码谋生，如果需要完整源代码请邮件联系作者。

感谢您对WisdomTool REST Client的支持与厚爱！

*****************************************
Author:  Dom Wang
Email:   witpool@outlook.com
*****************************************