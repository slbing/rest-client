﻿WisdomTool REST Client是由个人所开发的一款测试REST API的工具。

它可以测试REST API并生成精美的测试报告，同时基于测试过的历史数据，可以生成REST API文档。

如果 WisdomTool REST Client工具对您帮助很大，并且您很愿意支持工具的后续开发和维护，
您可以扫下方二维码随意打赏，就当是请我喝杯茶或是咖啡，将不胜感激。 ♥ 谢谢 ♥

感谢您对WisdomTool REST Client的支持与厚爱！

********************************************************************************************
作者   ： 王玉东 (Dom)

邮箱   ： wisdomtool@outlook.com

源代码  ： https://github.com/wisdomtool/rest-client/blob/master/restclient

捐助   ： https://github.com/wisdomtool/rest-client/blob/master/images/donate_pay.png
********************************************************************************************