﻿WisdomTool REST Client is an automated testing tool developed by individual.

This tool supports automated testing RESTful API, produced beautiful report, and automatically generating RESTful API documentation based on history cases. 

The author is now coding for a living. 

If you want to get the full source code, please contact the author by e-mail.

Thank you for your support for the WisdomTool REST Client!

*****************************************
Author:  Dom Wang
Email:   witpool@outlook.com
*****************************************
