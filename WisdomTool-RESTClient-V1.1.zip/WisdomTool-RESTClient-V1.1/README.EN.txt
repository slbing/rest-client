﻿WisdomTool REST Client is a testing tool developed by individual.

This tool supports testing REST API, produced beautiful report, and generating REST API documentation based on historical cases. 

If WisdomTool REST Client helps you a lot, and you would like to support this tool's further development and the continuous maintenance of this tool. You can sweep the following QR code free to donate me, which asked me to have a cup of tea or coffee. Your donation is highly appreciated. ♥ Thank you ♥

Thank you for your support for the WisdomTool REST Client!

********************************************************************************************
Author        : Yudong (Dom) Wang

Email         : wisdomtool@outlook.com

Source code   : https://github.com/wisdomtool/rest-client/blob/master/restclient

Donate by pay : https://github.com/wisdomtool/rest-client/blob/master/images/donate_pay.png
********************************************************************************************

